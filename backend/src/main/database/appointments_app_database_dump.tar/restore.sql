--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2 (Debian 14.2-1.pgdg110+1)
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE appointments_app_updated;
--
-- Name: appointments_app_updated; Type: DATABASE; Schema: -; Owner: web_app_user
--

CREATE DATABASE appointments_app_updated WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE appointments_app_updated OWNER TO web_app_user;

\connect appointments_app_updated

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: web_app; Type: SCHEMA; Schema: -; Owner: web_app_user
--

CREATE SCHEMA web_app;


ALTER SCHEMA web_app OWNER TO web_app_user;

--
-- Name: SCHEMA web_app; Type: COMMENT; Schema: -; Owner: web_app_user
--

COMMENT ON SCHEMA web_app IS 'DB schema used by appointments web application ';


--
-- Name: role; Type: TYPE; Schema: web_app; Owner: web_app_user
--

CREATE TYPE web_app.role AS ENUM (
    'admin',
    'manager',
    'secretary',
    'customer'
);


ALTER TYPE web_app.role OWNER TO web_app_user;

--
-- Name: states; Type: TYPE; Schema: web_app; Owner: web_app_user
--

CREATE TYPE web_app.states AS ENUM (
    'BOOKED',
    'CONFIRMED',
    'CHECKED_IN'
);


ALTER TYPE web_app.states OWNER TO web_app_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: web_app; Owner: web_app_user
--

CREATE TABLE web_app.appointments (
    id bigint NOT NULL,
    service integer NOT NULL,
    status web_app.states DEFAULT 'BOOKED'::web_app.states NOT NULL,
    datetime timestamp with time zone NOT NULL,
    "user" text NOT NULL
);


ALTER TABLE web_app.appointments OWNER TO web_app_user;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: web_app; Owner: web_app_user
--

CREATE SEQUENCE web_app.appointments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE web_app.appointments_id_seq OWNER TO web_app_user;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: web_app; Owner: web_app_user
--

ALTER SEQUENCE web_app.appointments_id_seq OWNED BY web_app.appointments.id;


--
-- Name: companies; Type: TABLE; Schema: web_app; Owner: web_app_user
--

CREATE TABLE web_app.companies (
    name text NOT NULL,
    address text NOT NULL,
    location point NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    admin text NOT NULL
);


ALTER TABLE web_app.companies OWNER TO web_app_user;

--
-- Name: departments; Type: TABLE; Schema: web_app; Owner: web_app_user
--

CREATE TABLE web_app.departments (
    id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    manager text NOT NULL,
    company text NOT NULL
);


ALTER TABLE web_app.departments OWNER TO web_app_user;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: web_app; Owner: web_app_user
--

CREATE SEQUENCE web_app.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE web_app.departments_id_seq OWNER TO web_app_user;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: web_app; Owner: web_app_user
--

ALTER SEQUENCE web_app.departments_id_seq OWNED BY web_app.departments.id;


--
-- Name: secretaries; Type: TABLE; Schema: web_app; Owner: web_app_user
--

CREATE TABLE web_app.secretaries (
    "user" text NOT NULL,
    department integer NOT NULL
);


ALTER TABLE web_app.secretaries OWNER TO web_app_user;

--
-- Name: services; Type: TABLE; Schema: web_app; Owner: web_app_user
--

CREATE TABLE web_app.services (
    id integer NOT NULL,
    name text NOT NULL,
    duration interval NOT NULL,
    description text NOT NULL,
    department integer NOT NULL
);


ALTER TABLE web_app.services OWNER TO web_app_user;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: web_app; Owner: web_app_user
--

CREATE SEQUENCE web_app.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE web_app.services_id_seq OWNER TO web_app_user;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: web_app; Owner: web_app_user
--

ALTER SEQUENCE web_app.services_id_seq OWNED BY web_app.services.id;


--
-- Name: timeslots; Type: TABLE; Schema: web_app; Owner: web_app_user
--

CREATE TABLE web_app.timeslots (
    service integer NOT NULL,
    datetime timestamp with time zone NOT NULL,
    places smallint NOT NULL
);


ALTER TABLE web_app.timeslots OWNER TO web_app_user;

--
-- Name: users; Type: TABLE; Schema: web_app; Owner: web_app_user
--

CREATE TABLE web_app.users (
    email text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    password text NOT NULL,
    role web_app.role DEFAULT 'customer'::web_app.role NOT NULL,
    salt text,
    verified boolean NOT NULL
);


ALTER TABLE web_app.users OWNER TO web_app_user;

--
-- Name: appointments id; Type: DEFAULT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.appointments ALTER COLUMN id SET DEFAULT nextval('web_app.appointments_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.departments ALTER COLUMN id SET DEFAULT nextval('web_app.departments_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.services ALTER COLUMN id SET DEFAULT nextval('web_app.services_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: web_app; Owner: web_app_user
--

COPY web_app.appointments (id, service, status, datetime, "user") FROM stdin;
\.
COPY web_app.appointments (id, service, status, datetime, "user") FROM '$$PATH$$/3367.dat';

--
-- Data for Name: companies; Type: TABLE DATA; Schema: web_app; Owner: web_app_user
--

COPY web_app.companies (name, address, location, phone, email, admin) FROM stdin;
\.
COPY web_app.companies (name, address, location, phone, email, admin) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: web_app; Owner: web_app_user
--

COPY web_app.departments (id, name, description, manager, company) FROM stdin;
\.
COPY web_app.departments (id, name, description, manager, company) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: secretaries; Type: TABLE DATA; Schema: web_app; Owner: web_app_user
--

COPY web_app.secretaries ("user", department) FROM stdin;
\.
COPY web_app.secretaries ("user", department) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: web_app; Owner: web_app_user
--

COPY web_app.services (id, name, duration, description, department) FROM stdin;
\.
COPY web_app.services (id, name, duration, description, department) FROM '$$PATH$$/3373.dat';

--
-- Data for Name: timeslots; Type: TABLE DATA; Schema: web_app; Owner: web_app_user
--

COPY web_app.timeslots (service, datetime, places) FROM stdin;
\.
COPY web_app.timeslots (service, datetime, places) FROM '$$PATH$$/3375.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: web_app; Owner: web_app_user
--

COPY web_app.users (email, name, phone, password, role, salt, verified) FROM stdin;
\.
COPY web_app.users (email, name, phone, password, role, salt, verified) FROM '$$PATH$$/3376.dat';

--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: web_app; Owner: web_app_user
--

SELECT pg_catalog.setval('web_app.appointments_id_seq', 4612, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: web_app; Owner: web_app_user
--

SELECT pg_catalog.setval('web_app.departments_id_seq', 130, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: web_app; Owner: web_app_user
--

SELECT pg_catalog.setval('web_app.services_id_seq', 213, true);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: secretaries secretaries_pkey; Type: CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.secretaries
    ADD CONSTRAINT secretaries_pkey PRIMARY KEY ("user");


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: timeslots timeslots_pkey; Type: CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.timeslots
    ADD CONSTRAINT timeslots_pkey PRIMARY KEY (service, datetime);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (email);


--
-- Name: appointments appointments_service_datetime_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.appointments
    ADD CONSTRAINT appointments_service_datetime_fkey FOREIGN KEY (service, datetime) REFERENCES web_app.timeslots(service, datetime) ON DELETE CASCADE;


--
-- Name: appointments appointments_user_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.appointments
    ADD CONSTRAINT appointments_user_fkey FOREIGN KEY ("user") REFERENCES web_app.users(email) ON DELETE CASCADE;


--
-- Name: companies companies_admin_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.companies
    ADD CONSTRAINT companies_admin_fkey FOREIGN KEY (admin) REFERENCES web_app.users(email) ON DELETE CASCADE;


--
-- Name: departments departments_company_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.departments
    ADD CONSTRAINT departments_company_fkey FOREIGN KEY (company) REFERENCES web_app.companies(name) ON DELETE CASCADE;


--
-- Name: departments departments_manager_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.departments
    ADD CONSTRAINT departments_manager_fkey FOREIGN KEY (manager) REFERENCES web_app.users(email) ON DELETE CASCADE;


--
-- Name: secretaries secretaries_department_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.secretaries
    ADD CONSTRAINT secretaries_department_fkey FOREIGN KEY (department) REFERENCES web_app.departments(id) ON DELETE CASCADE;


--
-- Name: secretaries secretaries_user_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.secretaries
    ADD CONSTRAINT secretaries_user_fkey FOREIGN KEY ("user") REFERENCES web_app.users(email) ON DELETE CASCADE;


--
-- Name: services services_department_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.services
    ADD CONSTRAINT services_department_fkey FOREIGN KEY (department) REFERENCES web_app.departments(id) ON DELETE CASCADE;


--
-- Name: timeslots timeslots_service_fkey; Type: FK CONSTRAINT; Schema: web_app; Owner: web_app_user
--

ALTER TABLE ONLY web_app.timeslots
    ADD CONSTRAINT timeslots_service_fkey FOREIGN KEY (service) REFERENCES web_app.services(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

